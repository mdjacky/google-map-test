# google-map-test

Text Search for google map

Features:
1. Search results are listed in the table.
2. User can order the table according to name and address.
3. User can select place in the table. The selected place will show a pop-up window in the map;
4. User can select place in the map. The selected place will be highlighted in the table.
5. Added 'disabled' function to prevent user from hitting search button too often.

Comments: I tested with nginx. Simply open index.html may not work.